## $5 Tech Unlocked 2021!
[Buy and download this product for only $5 on PacktPub.com](https://www.packtpub.com/)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Learning Continuous Integration with Jenkins

*[Learning Continuous Integration with Jenkins](https://www.packtpub.com/networking-and-servers/learning-continuous-integration-jenkins?utm_source=github&utm_medium=repository&utm_campaign=9781785284830)*, serves as a step-by-step guide to set up Continuous Integration, Continuous Delivery, and Continuous Deployment system using hands-on examples. 

For further reading, you can also refer to the following books:
* [Jenkins Continuous Integration Cookbook - Second Edition](https://www.packtpub.com/application-development/jenkins-continuous-integration-cookbook-second-edition)
* [Jenkins Essentials](https://www.packtpub.com/application-development/jenkins-essentials)
* [Mastering Jenkins](https://www.packtpub.com/application-development/mastering-jenkins)





